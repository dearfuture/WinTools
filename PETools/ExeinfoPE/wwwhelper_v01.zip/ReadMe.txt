*************************************************
*                                               *
* plugin for Exeinfo Pe / PeiD                  *
*                                               *
*                              wwwHelper v.0.1  *
*                                               *
*                             created by A.S.L  *
*                                               *
* www.exeinfo.xn.pl                             *
*                                               *
*************************************************

 usage : copy file to \plugins directory
